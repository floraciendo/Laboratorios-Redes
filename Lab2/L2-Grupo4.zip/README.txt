Integrantes:
  José Castro, 202073550-6
  Florencia Ramírez, 202073522-0

☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆

Instrucciones de compilación:
  Se debe esperar antes de hacer alguna prueba para que las redes se conecten correctamente.
  El primer mensaje no se va a enviar, se elimina y se debe hacer nuevamente.
